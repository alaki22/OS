#include "kernel/types.h"
#include "kernel/fcntl.h"
#include "user/user.h"
#include "kernel/riscv.h"

int
main(int argc, char *argv[])
{

   char *start = sbrk(PGSIZE * 11);  
  char pw[8];
  for(int i = PGSIZE*8; i < PGSIZE*9; i++) {
    if (start[i] >= 32 && start[i] <= 126) {
      if(strlen(start + i) != 7){
        continue;
      }
      for(int j = 0; j< 7; j++){
        pw[j] = start[i+j];
      }
      break;
    }
  }

  pw[7] = '\0';
  write(2, pw, 8);


  exit(0);
}
